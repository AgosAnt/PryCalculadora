
from django.apps import AppConfig

class RaicesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'raices_app'
