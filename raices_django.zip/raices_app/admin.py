
from django.contrib import admin

# Register your models here (no models needed for this app).
